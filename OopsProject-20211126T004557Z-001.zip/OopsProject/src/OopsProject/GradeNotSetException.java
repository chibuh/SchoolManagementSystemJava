package OopsProject;

public class GradeNotSetException extends Exception{
	public GradeNotSetException(String errorMessage) {
        super(errorMessage);
    }	
}
