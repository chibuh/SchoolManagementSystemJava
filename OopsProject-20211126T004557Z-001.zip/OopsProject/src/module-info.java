module OopsProject {
	requires java.desktop;
	requires java.sql;
}